package org.unibl.etf.projektnizadatak2024.interfaces;

public interface MultiPassenger {
}
